import { TopBar } from "../components/TopBar";
import { NavBar } from "../components/NavBar";
import { Hero } from "../components/Hero";
import { TrustBar } from "../components/TrustBar";
import { BentoServices } from "../components/BentoServices";
import { Methodology } from "../components/Methodology";
import { Industries } from "../components/Industries";
import { WhatsAppFAB } from "../components/WhatsAppFAB";
import { Footer } from "../components/Footer";

export function Home() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-[#25D366]/30 selection:text-slate-900">
      <TopBar />
      <NavBar />
      <main>
        <Hero />
        <TrustBar />
        <BentoServices />
        <Methodology />
        <Industries />
      </main>
      <Footer />
      <WhatsAppFAB />
    </div>
  );
}
