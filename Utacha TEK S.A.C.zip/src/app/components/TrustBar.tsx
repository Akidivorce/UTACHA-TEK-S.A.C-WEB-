import { motion } from "motion/react";

export function TrustBar() {
  const partners = [
    { name: "Motorola Solutions" },
    { name: "Kenwood" },
    { name: "Icom" },
    { name: "Hytera" },
    { name: "TXPRO" },
  ];

  return (
    <div className="border-y border-slate-200 bg-white py-12 overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <p className="text-center text-sm font-semibold text-slate-500 uppercase tracking-widest mb-8">
          Tecnología respaldada por líderes globales:
        </p>
        <div className="flex flex-wrap justify-center md:justify-between items-center gap-8 md:gap-12 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
          {partners.map((partner, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-xl md:text-2xl font-black text-slate-800 tracking-tighter"
            >
              {partner.name.toUpperCase()}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
