import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';

export const FloatingWhatsAppButton = () => {
  const [isHovered, setIsHovered] = useState(false);
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-8 right-8 z-50">
      <div className="relative">
        {isHovered && (
          <div className="absolute bottom-full right-0 mb-4 w-64 bg-white rounded-xl shadow-2xl p-4 border border-slate-200 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <p className="text-sm font-semibold text-[#0B1120] mb-1">
              ¿Dudas técnicas?
            </p>
            <p className="text-xs text-slate-600">
              Chatea con un ingeniero especializado
            </p>
            <div className="absolute bottom-0 right-8 transform translate-y-1/2 rotate-45 w-3 h-3 bg-white border-r border-b border-slate-200"></div>
          </div>
        )}

        <button
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          className="flex items-center gap-3 bg-[#25D366] hover:bg-[#1da851] text-white pl-6 pr-6 py-4 rounded-full font-bold transition-all shadow-2xl hover:shadow-[0_20px_60px_-15px_rgba(37,211,102,0.5)] hover:scale-105 group"
        >
          <MessageCircle className="w-6 h-6 animate-pulse" />
          <span className="text-sm">WhatsApp</span>
        </button>

        <button
          onClick={() => setIsVisible(false)}
          className="absolute -top-2 -right-2 w-6 h-6 bg-slate-800 hover:bg-slate-700 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <X className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
