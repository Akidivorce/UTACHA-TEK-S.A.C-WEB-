import React from 'react';
import { MessageCircle, Phone, Mail } from 'lucide-react';

export const CTA = () => {
  return (
    <section className="bg-gradient-to-br from-[#0B1120] via-blue-950 to-[#0B1120] py-24 relative overflow-hidden" id="contacto">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2ZmZmZmZiIgc3Ryb2tlLW9wYWNpdHk9IjAuMDMiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-40"></div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-900/50 backdrop-blur-sm border border-blue-700/50 mb-6">
          <span className="flex h-2 w-2 rounded-full bg-[#25D366] animate-pulse"></span>
          <span className="text-xs font-bold text-blue-200 uppercase tracking-wider">
            Atención Empresarial Directa
          </span>
        </div>

        <h2 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white mb-6 tracking-tight leading-tight">
          ¿Necesitas un Presupuesto Formal o Asesoría Técnica?
        </h2>
        <p className="text-lg lg:text-xl text-slate-300 mb-12 max-w-3xl mx-auto leading-relaxed">
          Nuestros ingenieros especialistas están listos para analizar tu proyecto y ofrecerte soluciones a medida con dos opciones de presupuesto.
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
          <button className="inline-flex justify-center items-center gap-3 bg-[#25D366] hover:bg-[#1da851] text-white px-10 py-5 rounded-xl font-bold text-lg transition-all shadow-2xl hover:shadow-[0_20px_60px_-15px_rgba(37,211,102,0.5)] hover:-translate-y-1">
            <MessageCircle className="w-6 h-6" />
            Cotizar por WhatsApp
          </button>
          <button className="inline-flex justify-center items-center gap-3 bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white border-2 border-white/30 px-10 py-5 rounded-xl font-bold text-lg transition-all">
            <Phone className="w-6 h-6" />
            Llamar Ahora
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-6 h-6 text-blue-300" />
            </div>
            <h3 className="text-white font-bold mb-2 text-sm">Respuesta Rápida</h3>
            <p className="text-slate-400 text-xs">WhatsApp empresarial activo 24/7</p>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Phone className="w-6 h-6 text-green-300" />
            </div>
            <h3 className="text-white font-bold mb-2 text-sm">Asesoría Técnica</h3>
            <p className="text-slate-400 text-xs">Ingenieros certificados disponibles</p>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6">
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Mail className="w-6 h-6 text-purple-300" />
            </div>
            <h3 className="text-white font-bold mb-2 text-sm">Cotización Formal</h3>
            <p className="text-slate-400 text-xs">Propuestas detalladas en 48 hrs</p>
          </div>
        </div>
      </div>
    </section>
  );
};
