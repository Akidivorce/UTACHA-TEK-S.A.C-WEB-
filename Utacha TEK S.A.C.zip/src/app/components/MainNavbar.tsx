import React, { useState, useEffect } from 'react';
import { Menu, X, Radio, MessageCircle } from 'lucide-react';

export const MainNavbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed w-full z-50 bg-white transition-all duration-300 ${
        isScrolled ? 'shadow-md border-b border-slate-200' : 'border-b border-slate-100'
      }`}
      style={{ top: '0' }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center gap-2.5">
            <div className="bg-[#0B1120] p-2.5 rounded-lg shadow-sm">
              <Radio className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-[#0B1120] tracking-tight">
              Utacha <span className="text-slate-500 font-semibold">TEK</span>
            </span>
          </div>

          <div className="hidden lg:flex items-center space-x-8">
            <a href="#infraestructura" className="text-slate-700 hover:text-[#0B1120] font-medium transition-colors text-sm">
              Infraestructura
            </a>
            <a href="#equipos" className="text-slate-700 hover:text-[#0B1120] font-medium transition-colors text-sm">
              Equipos
            </a>
            <a href="#proyectos" className="text-slate-700 hover:text-[#0B1120] font-medium transition-colors text-sm">
              Proyectos
            </a>
            <a href="#soporte" className="text-slate-700 hover:text-[#0B1120] font-medium transition-colors text-sm">
              Soporte
            </a>
            <button className="flex items-center gap-2 bg-[#25D366] hover:bg-[#1da851] text-white px-6 py-3 rounded-lg font-semibold transition-all shadow-sm hover:shadow-md text-sm">
              <MessageCircle className="w-4 h-4" />
              Asesoría por WhatsApp
            </button>
          </div>

          <div className="lg:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-900 p-2">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="lg:hidden bg-white border-t border-slate-100 shadow-lg">
          <div className="px-4 pt-2 pb-6 space-y-2">
            <a href="#infraestructura" className="block px-3 py-3 text-slate-600 hover:bg-slate-50 rounded-md font-medium">
              Infraestructura
            </a>
            <a href="#equipos" className="block px-3 py-3 text-slate-600 hover:bg-slate-50 rounded-md font-medium">
              Equipos
            </a>
            <a href="#proyectos" className="block px-3 py-3 text-slate-600 hover:bg-slate-50 rounded-md font-medium">
              Proyectos
            </a>
            <a href="#soporte" className="block px-3 py-3 text-slate-600 hover:bg-slate-50 rounded-md font-medium">
              Soporte
            </a>
            <button className="w-full mt-4 flex justify-center items-center gap-2 bg-[#25D366] hover:bg-[#1da851] text-white px-6 py-3 rounded-lg font-semibold transition-colors shadow-sm">
              <MessageCircle className="w-4 h-4" />
              Asesoría por WhatsApp
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};
