import React from 'react';
import { Radio, MapPin, Phone, Mail, Linkedin, Twitter, Facebook, Youtube, ExternalLink } from 'lucide-react';

const footerLinks = {
  company: [
    { name: 'Acerca de Utacha TEK', href: '#' },
    { name: 'Casos de Éxito', href: '#' },
    { name: 'Certificaciones', href: '#' },
    { name: 'Blog Técnico', href: '#' },
    { name: 'Trabaja con Nosotros', href: '#' }
  ],
  services: [
    { name: 'Radiocomunicación Digital', href: '#' },
    { name: 'Infraestructura de Red', href: '#' },
    { name: 'Equipos Tácticos', href: '#' },
    { name: 'Mantenimiento Preventivo', href: '#' },
    { name: 'Consultoría Especializada', href: '#' }
  ],
  partners: [
    { name: 'Motorola Solutions', href: '#', external: true },
    { name: 'Kenwood Professional', href: '#', external: true },
    { name: 'Icom Incorporated', href: '#', external: true },
    { name: 'Hytera Communications', href: '#', external: true },
    { name: 'TXPRO', href: '#', external: true }
  ],
  legal: [
    { name: 'Política de Privacidad', href: '#' },
    { name: 'Términos de Servicio', href: '#' },
    { name: 'Política de Garantías', href: '#' },
    { name: 'Cumplimiento Regulatorio', href: '#' }
  ]
};

export const CorporateFooter = () => {
  return (
    <footer className="bg-[#0B1120] text-slate-300 pt-20 pb-10 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5 mb-6">
              <div className="bg-blue-600 p-2.5 rounded-lg shadow-lg">
                <Radio className="h-7 w-7 text-white" />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">
                Utacha <span className="text-blue-400 font-semibold">TEK</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed mb-6 max-w-sm">
              Ingeniería especializada en radiocomunicación y telecomunicaciones. Proveemos soluciones de conectividad crítica para industrias de alta exigencia.
            </p>
            <div className="flex space-x-4 mb-8">
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                <span className="text-slate-400">
                  Av. Tecnológico 500, Piso 12<br />
                  Parque Industrial Norte, CP 64000
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-blue-400 flex-shrink-0" />
                <span className="text-slate-400">+52 (81) 8888-9999</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-blue-400 flex-shrink-0" />
                <span className="text-slate-400">ventas@utachatek.com</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-white font-bold mb-6 uppercase text-xs tracking-wider">
              Empresa
            </h3>
            <ul className="space-y-3 text-sm">
              {footerLinks.company.map((link, idx) => (
                <li key={idx}>
                  <a href={link.href} className="text-slate-400 hover:text-blue-400 transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-6 uppercase text-xs tracking-wider">
              Soluciones
            </h3>
            <ul className="space-y-3 text-sm">
              {footerLinks.services.map((link, idx) => (
                <li key={idx}>
                  <a href={link.href} className="text-slate-400 hover:text-blue-400 transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-6 uppercase text-xs tracking-wider">
              Marcas Asociadas
            </h3>
            <ul className="space-y-3 text-sm">
              {footerLinks.partners.map((link, idx) => (
                <li key={idx}>
                  <a
                    href={link.href}
                    className="text-slate-400 hover:text-blue-400 transition-colors flex items-center gap-1.5"
                  >
                    {link.name}
                    {link.external && <ExternalLink className="w-3 h-3" />}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="bg-slate-900/50 rounded-2xl p-8 mb-12">
          <h3 className="text-white font-bold mb-4 text-lg">
            Suscríbete a Nuestro Boletín Técnico
          </h3>
          <p className="text-sm text-slate-400 mb-6">
            Recibe novedades sobre tecnología de radiocomunicación, lanzamientos y casos de éxito.
          </p>
          <form className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              placeholder="ingeniero@empresa.com"
              className="flex-1 px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg transition-colors text-sm"
            >
              Suscribirse
            </button>
          </form>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
          <p>
            &copy; {new Date().getFullYear()} Utacha TEK. Todos los derechos reservados.
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            {footerLinks.legal.map((link, idx) => (
              <a key={idx} href={link.href} className="hover:text-blue-400 transition-colors">
                {link.name}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};
