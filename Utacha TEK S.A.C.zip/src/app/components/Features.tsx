import React from 'react';
import { Network, Server, Fingerprint, Headset } from 'lucide-react';

const features = [
  {
    icon: <Network className="w-8 h-8 text-blue-600" />,
    title: 'Infraestructura Robusta',
    description: 'Diseñamos e implementamos redes de alta disponibilidad que garantizan la continuidad de tus operaciones críticas en todo momento.',
    color: 'bg-blue-50'
  },
  {
    icon: <Server className="w-8 h-8 text-cyan-600" />,
    title: 'Tecnología Avanzada',
    description: 'Equipamiento de última generación y software especializado para gestión, monitoreo y control de flotas y comunicaciones.',
    color: 'bg-cyan-50'
  },
  {
    icon: <Fingerprint className="w-8 h-8 text-blue-600" />,
    title: 'Máxima Seguridad',
    description: 'Protocolos de encriptación y sistemas de radio digital (DMR, TETRA) para mantener la privacidad de tus comunicaciones empresariales.',
    color: 'bg-blue-50'
  },
  {
    icon: <Headset className="w-8 h-8 text-cyan-600" />,
    title: 'Soporte Especializado 24/7',
    description: 'Nuestro equipo de ingenieros y técnicos está disponible permanentemente para resolver incidencias y realizar mantenimiento preventivo.',
    color: 'bg-cyan-50'
  }
];

export const Features = () => {
  return (
    <section className="py-24 bg-white" id="nosotros">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-blue-600 font-semibold tracking-wide uppercase mb-3 text-sm">¿Por qué elegir Utacha TEK?</h2>
          <p className="mt-2 text-4xl font-extrabold text-slate-900 tracking-tight sm:text-5xl">
            Solidez y Confianza en Cada Conexión
          </p>
          <p className="mt-6 text-xl text-slate-500 leading-relaxed">
            Nos dedicamos a proveer soluciones de telecomunicaciones que transforman la manera en que las empresas se comunican y operan.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="relative p-8 bg-white border border-slate-100 rounded-3xl shadow-sm hover:shadow-xl hover:border-blue-100 transition-all duration-300 group"
            >
              <div className={`inline-flex items-center justify-center p-4 rounded-2xl ${feature.color} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-blue-600 transition-colors">
                {feature.title}
              </h3>
              <p className="text-slate-600 leading-relaxed text-sm">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
