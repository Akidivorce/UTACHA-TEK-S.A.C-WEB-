import { motion } from "motion/react";
import { HardHat, Shield, Truck, Settings } from "lucide-react";

import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Industries() {
  const industries = [
    {
      name: "Minería",
      description: "Cobertura profunda y equipos intrínsecamente seguros.",
      icon: <Settings className="w-8 h-8 text-[#25D366]" />,
      image: "https://images.unsplash.com/photo-1761432339044-cfd862009b50?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbmclMjBpbmR1c3RyeSUyMGRhcmt8ZW58MXx8fHwxNzc0ODg2NzQwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      name: "Seguridad Privada",
      description: "Despliegue rápido y comunicaciones encriptadas.",
      icon: <Shield className="w-8 h-8 text-[#25D366]" />,
      image: "https://images.unsplash.com/photo-1672073311074-f60c4a5e7b92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWN1cml0eSUyMGd1YXJkJTIwc3VydmVpbGxhbmNlfGVufDF8fHx8MTc3NDg4Njc0MHww&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      name: "Construcción",
      description: "Soluciones robustas para ambientes de alta interferencia.",
      icon: <HardHat className="w-8 h-8 text-[#25D366]" />,
      image: "https://images.unsplash.com/photo-1694521787162-5373b598945c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBzaXRlJTIwd29ya2VyJTIwZW5naW5lZXJpbmd8ZW58MXx8fHwxNzc0ODg2NzQwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      name: "Logística",
      description: "Rastreo GPS integrado y cobertura regional amplia.",
      icon: <Truck className="w-8 h-8 text-[#25D366]" />,
      image: "https://images.unsplash.com/photo-1771387515473-a7b737d70efb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsb2dpc3RpY3MlMjB0cnVjayUyMHdhcmVob3VzZSUyMGRhcmt8ZW58MXx8fHwxNzc0ODg2NzQwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
  ];

  return (
    <section className="py-24 bg-slate-900" id="industrias">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 tracking-tight">
              Industrias Críticas
            </h2>
            <p className="text-lg text-slate-400">
              Proveemos soluciones de telecomunicación ininterrumpida a sectores que no pueden permitirse fallas operativas.
            </p>
          </div>
          <div>
            <a
              href="#contact"
              className="inline-flex items-center space-x-2 text-[#25D366] font-semibold hover:text-white transition-colors border border-[#25D366] hover:bg-[#25D366]/10 px-6 py-3 rounded-lg"
            >
              <span>Hablar con un ingeniero</span>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {industries.map((ind, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.15, duration: 0.5 }}
              className="group relative h-[400px] rounded-2xl overflow-hidden cursor-pointer"
            >
              <div className="absolute inset-0 z-0">
                <ImageWithFallback
                  src={ind.image}
                  alt={ind.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-slate-900/60 group-hover:bg-slate-900/40 transition-colors duration-500"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent"></div>
              </div>
              
              <div className="absolute inset-0 z-10 p-8 flex flex-col justify-end">
                <div className="mb-4 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500 bg-white/10 backdrop-blur-md w-14 h-14 rounded-xl flex items-center justify-center border border-white/20">
                  {ind.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  {ind.name}
                </h3>
                <p className="text-slate-300 text-sm leading-relaxed opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                  {ind.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
