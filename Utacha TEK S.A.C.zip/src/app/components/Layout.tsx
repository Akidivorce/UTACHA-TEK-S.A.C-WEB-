import React from 'react';
import { Outlet } from 'react-router';
import { TopBar } from './TopBar';
import { MainNavbar } from './MainNavbar';
import { HeroSplit } from './HeroSplit';
import { TrustBar } from './TrustBar';
import { BentoGrid } from './BentoGrid';
import { Methodology } from './Methodology';
import { Industries } from './Industries';
import { CTA } from './CTA';
import { CorporateFooter } from './CorporateFooter';
import { FloatingWhatsAppButton } from './FloatingWhatsAppButton';

export const LandingPage = () => {
  return (
    <div className="min-h-screen bg-white font-sans selection:bg-[#25D366] selection:text-white scroll-smooth antialiased">
      <TopBar />
      <MainNavbar />
      <main>
        <HeroSplit />
        <TrustBar />
        <BentoGrid />
        <Methodology />
        <Industries />
        <CTA />
      </main>
      <CorporateFooter />
      <FloatingWhatsAppButton />
    </div>
  );
};

export const Root = () => {
  return <Outlet />;
};
