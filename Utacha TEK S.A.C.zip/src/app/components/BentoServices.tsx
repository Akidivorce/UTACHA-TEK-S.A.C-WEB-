import { motion } from "motion/react";
import { Radio, PhoneCall, Zap, ClipboardCheck, ArrowRight } from "lucide-react";

export function BentoServices() {
  const cards = [
    {
      title: "Infraestructura y Repetidoras",
      description: "Diseño e implementación de redes de amplia cobertura para garantizar comunicaciones estables en áreas críticas y remotas.",
      icon: <Radio className="w-8 h-8 text-[#25D366]" />,
      colSpan: "md:col-span-2",
      bgClass: "bg-slate-900 text-white border-slate-800",
      textClass: "text-slate-300",
      titleClass: "text-white",
      large: true,
    },
    {
      title: "Terminales de Radiocomunicación",
      description: "Equipos portátiles y móviles diseñados para uso rudo, resistentes al polvo y agua (IP67/IP68).",
      icon: <PhoneCall className="w-6 h-6 text-slate-700 group-hover:text-[#25D366] transition-colors" />,
      colSpan: "md:col-span-1",
      bgClass: "bg-white border-slate-200 shadow-sm hover:shadow-md transition-shadow",
      textClass: "text-slate-600",
      titleClass: "text-slate-900",
      large: false,
    },
    {
      title: "Sistemas de Antenas y Enlaces",
      description: "Optimización de propagación de señal con hardware de precisión para máxima ganancia.",
      icon: <Zap className="w-6 h-6 text-slate-700 group-hover:text-[#25D366] transition-colors" />,
      colSpan: "md:col-span-1",
      bgClass: "bg-white border-slate-200 shadow-sm hover:shadow-md transition-shadow",
      textClass: "text-slate-600",
      titleClass: "text-slate-900",
      large: false,
    },
    {
      title: "Consultoría Técnica Integral",
      description: "Análisis de parámetros, opciones de presupuesto y pruebas de campo para soluciones a medida.",
      icon: <ClipboardCheck className="w-6 h-6 text-slate-700 group-hover:text-[#25D366] transition-colors" />,
      colSpan: "md:col-span-2 lg:col-span-1",
      bgClass: "bg-slate-50 border-slate-200 shadow-sm hover:border-[#25D366]/50 transition-colors",
      textClass: "text-slate-600",
      titleClass: "text-slate-900",
      large: false,
    },
  ];

  return (
    <section className="py-24 bg-slate-50" id="soluciones">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4 tracking-tight">
            Soluciones Core <span className="text-[#25D366]">B2B</span>
          </h2>
          <p className="text-lg text-slate-600">
            Desplegamos infraestructura de misión crítica adaptada a las necesidades operativas de su empresa.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-[minmax(200px,auto)]">
          {cards.map((card, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              className={`group p-8 rounded-2xl border ${card.bgClass} ${card.colSpan} flex flex-col justify-between overflow-hidden relative`}
            >
              {card.large && (
                <div className="absolute right-0 top-0 w-64 h-64 bg-gradient-to-bl from-slate-800 to-transparent rounded-bl-full -mr-16 -mt-16 pointer-events-none"></div>
              )}
              
              <div className="mb-8 relative z-10">
                <div className="mb-6 inline-flex items-center justify-center w-14 h-14 rounded-xl bg-slate-800/10 border border-slate-700/20 backdrop-blur-sm">
                  {card.icon}
                </div>
                <h3 className={`text-xl md:text-2xl font-bold mb-3 ${card.titleClass}`}>
                  {card.title}
                </h3>
                <p className={`text-base leading-relaxed ${card.textClass}`}>
                  {card.description}
                </p>
              </div>
              
              <div className="mt-auto relative z-10">
                <a
                  href="#contact"
                  className={`inline-flex items-center space-x-2 font-semibold text-sm hover:underline ${
                    card.large ? "text-[#25D366]" : "text-slate-900"
                  }`}
                >
                  <span>Conocer más</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
