import { Radio, MapPin, Mail, Phone, ChevronRight } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300 pt-20 pb-10 border-t border-slate-900">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Col */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <Radio className="w-8 h-8 text-[#25D366]" />
              <span className="text-2xl font-bold text-white tracking-tight">Utacha TEK</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Ingeniería en telecomunicaciones y radiocomunicación. Soluciones tácticas y corporativas de alta disponibilidad.
            </p>
            <div className="flex space-x-4">
              <div className="w-10 h-10 rounded-full bg-slate-900 flex items-center justify-center hover:bg-[#25D366]/20 hover:text-[#25D366] transition-colors cursor-pointer">
                <span className="sr-only">LinkedIn</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                </svg>
              </div>
            </div>
          </div>

          {/* Links Col */}
          <div>
            <h4 className="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Nuestras Marcas</h4>
            <ul className="space-y-3">
              {["Motorola Solutions", "Kenwood", "Icom", "Hytera", "TXPRO"].map((brand) => (
                <li key={brand}>
                  <a href="#" className="flex items-center text-slate-400 hover:text-[#25D366] transition-colors">
                    <ChevronRight className="w-4 h-4 mr-2 text-slate-700" />
                    <span>{brand}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Col */}
          <div>
            <h4 className="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Contacto & Soporte</h4>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-slate-500 mt-0.5 shrink-0" />
                <span className="text-slate-400">Av. Ingeniería #405, Parque Industrial, Ciudad Técnica.</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-slate-500 shrink-0" />
                <span className="text-slate-400">+52 (55) 1234-5678</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-slate-500 shrink-0" />
                <span className="text-slate-400">proyectos@utachatek.com</span>
              </li>
            </ul>
          </div>

          {/* Newsletter Col */}
          <div>
            <h4 className="text-white font-semibold mb-6 uppercase tracking-wider text-sm">Boletín Técnico</h4>
            <p className="text-slate-400 mb-4 text-sm">
              Reciba actualizaciones sobre normativas de RF, nuevos equipos y casos de éxito.
            </p>
            <form className="space-y-3" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="Ingeniero@empresa.com"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:border-[#25D366] focus:ring-1 focus:ring-[#25D366] transition-all"
              />
              <button
                type="submit"
                className="w-full bg-slate-800 hover:bg-slate-700 text-white font-medium px-4 py-3 rounded-lg transition-colors border border-slate-700 hover:border-slate-600"
              >
                Suscribirse
              </button>
            </form>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col md:flex-row items-center justify-between text-sm text-slate-500">
          <p>© {new Date().getFullYear()} Utacha TEK. Todos los derechos reservados.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Aviso de Privacidad</a>
            <a href="#" className="hover:text-white transition-colors">Términos de Servicio</a>
            <a href="#" className="hover:text-white transition-colors">Políticas de Garantía</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
