import { motion } from "motion/react";
import { MessageCircle, ArrowRight, Activity } from "lucide-react";

import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-slate-50 pt-16 md:pt-24 lg:pt-32 pb-16">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Left Text */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center space-x-2 bg-slate-100 text-slate-600 px-3 py-1 rounded-full text-sm font-medium mb-6 border border-slate-200">
              <span className="flex h-2 w-2 rounded-full bg-[#25D366]"></span>
              <span>Líderes en Telecomunicaciones B2B</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.1] mb-6">
              Ingeniería en Radiocomunicación y <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#25D366] to-[#128C7E]">Conectividad Ininterrumpida</span>
            </h1>
            
            <p className="text-lg md:text-xl text-slate-600 mb-8 max-w-xl leading-relaxed">
              Diseño, parametrización y despliegue de redes de comunicación a medida. Equipamiento táctico e infraestructura para operaciones críticas.
            </p>
            
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <a
                href="#whatsapp"
                className="inline-flex items-center justify-center space-x-2 bg-[#25D366] hover:bg-[#20bd5a] text-white px-6 py-3.5 rounded-lg font-semibold transition-all shadow-lg shadow-[#25D366]/25 hover:shadow-[#25D366]/40"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Cotizar Proyecto (WhatsApp)</span>
              </a>
              <a
                href="#soluciones"
                className="inline-flex items-center justify-center space-x-2 bg-white border-2 border-slate-200 hover:border-slate-300 text-slate-700 hover:bg-slate-50 px-6 py-3.5 rounded-lg font-semibold transition-all"
              >
                <span>Explorar Soluciones</span>
                <ArrowRight className="w-5 h-5" />
              </a>
            </div>
            
            <div className="mt-8 flex items-center space-x-4 text-sm font-medium text-slate-500">
              <div className="flex items-center">
                <Activity className="w-4 h-4 mr-1.5 text-[#25D366]" />
                <span>99.9% Uptime</span>
              </div>
              <div className="flex items-center">
                <Activity className="w-4 h-4 mr-1.5 text-[#25D366]" />
                <span>Soporte 24/7</span>
              </div>
            </div>
          </motion.div>

          {/* Right Graphic/Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative lg:ml-auto"
          >
            {/* Background decorative elements */}
            <div className="absolute inset-0 bg-gradient-to-tr from-slate-900/10 to-[#25D366]/10 rounded-3xl blur-3xl transform scale-110 -z-10"></div>
            
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-slate-200/50 bg-white p-2">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1689672921275-ac0f8f462f82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWxlY29tbXVuaWNhdGlvbnMlMjB0b3dlciUyMHJhZGlvJTIwZnJlcXVlbmN5fGVufDF8fHx8MTc3NDg4Njc0MHww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Infraestructura de Radiocomunicación"
                className="w-full h-auto rounded-xl object-cover aspect-[4/3] md:aspect-square lg:aspect-[4/3]"
              />
              
              {/* Floating tech badge */}
              <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-md rounded-xl p-4 shadow-lg border border-slate-100 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Status de Red</p>
                  <div className="flex items-center space-x-2">
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#25D366] opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-[#25D366]"></span>
                    </span>
                    <span className="font-semibold text-slate-900">Operación Óptima</span>
                  </div>
                </div>
                <div className="h-10 w-24 bg-slate-50 rounded border border-slate-100 flex items-center justify-center space-x-1 p-1">
                   {[40, 70, 45, 90, 65, 80].map((h, i) => (
                     <div key={i} className="w-1.5 bg-[#25D366] rounded-sm" style={{ height: `${h}%` }}></div>
                   ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
