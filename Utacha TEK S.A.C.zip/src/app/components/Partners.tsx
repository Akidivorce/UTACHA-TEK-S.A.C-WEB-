import React from 'react';

const brands = [
  { name: 'MOTOROLA', font: 'font-black' },
  { name: 'KENWOOD', font: 'font-extrabold tracking-tighter' },
  { name: 'ICOM', font: 'font-bold italic' },
  { name: 'HYTERA', font: 'font-black tracking-widest' },
  { name: 'TXPRO', font: 'font-bold tracking-tight' }
];

export const Partners = () => {
  return (
    <div className="bg-white border-b border-slate-200 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-xs font-bold text-slate-400 uppercase tracking-widest mb-8">
          Distribuidores de confianza:
        </p>
        <div className="flex flex-wrap justify-center gap-10 md:gap-20 items-center opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
          {brands.map((brand, idx) => (
            <span key={idx} className={`text-2xl text-slate-800 ${brand.font} select-none`}>
              {brand.name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
