import React from 'react';
import { Radio, Wifi, ClipboardList } from 'lucide-react';

const solutions = [
  {
    title: 'Venta de Equipos',
    description: 'Radios portátiles y móviles para uso rudo y corporativo.',
    icon: <Radio className="w-8 h-8 text-blue-950" />
  },
  {
    title: 'Infraestructura',
    description: 'Antenas y repetidoras de frecuencia para máxima cobertura.',
    icon: <Wifi className="w-8 h-8 text-blue-950" />
  },
  {
    title: 'Proyectos a Medida',
    description: 'Asesoría, presupuestos (opción 1 y 2) y parámetros técnicos personalizados.',
    icon: <ClipboardList className="w-8 h-8 text-blue-950" />
  }
];

export const Services = () => {
  return (
    <section className="py-24 bg-slate-50" id="soluciones">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-bold tracking-widest text-blue-600 uppercase mb-3">Nuestras Soluciones</h2>
          <p className="text-3xl font-extrabold text-blue-950 tracking-tight sm:text-4xl">
            Ingeniería Aplicada a tu Operación
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {solutions.map((solution, index) => (
            <div 
              key={index} 
              className="bg-white p-8 rounded-lg border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="inline-flex items-center justify-center p-4 rounded-md bg-slate-100 mb-6">
                {solution.icon}
              </div>
              <h3 className="text-xl font-bold text-blue-950 mb-3">
                {solution.title}
              </h3>
              <p className="text-slate-600 leading-relaxed">
                {solution.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
