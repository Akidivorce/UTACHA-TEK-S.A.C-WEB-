import React, { useState } from 'react';
import { Menu, X, Radio, MessageCircle } from 'lucide-react';

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full z-50 bg-white border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center gap-2">
            <div className="bg-blue-950 p-2 rounded-md">
              <Radio className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-blue-950 tracking-tight">
              Utacha <span className="text-slate-500">TEK</span>
            </span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#nosotros" className="text-slate-600 hover:text-blue-950 font-medium transition-colors">Nosotros</a>
            <a href="#soluciones" className="text-slate-600 hover:text-blue-950 font-medium transition-colors">Soluciones</a>
            <a href="#proyectos" className="text-slate-600 hover:text-blue-950 font-medium transition-colors">Proyectos</a>
            <button className="flex items-center gap-2 bg-blue-950 hover:bg-blue-900 text-white px-5 py-2.5 rounded-md font-semibold transition-all shadow-sm">
              Contacto Rápido
            </button>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-900 p-2">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 shadow-lg">
          <div className="px-4 pt-2 pb-6 space-y-2">
            <a href="#nosotros" className="block px-3 py-3 text-slate-600 hover:bg-slate-50 rounded-md font-medium">Nosotros</a>
            <a href="#soluciones" className="block px-3 py-3 text-slate-600 hover:bg-slate-50 rounded-md font-medium">Soluciones</a>
            <a href="#proyectos" className="block px-3 py-3 text-slate-600 hover:bg-slate-50 rounded-md font-medium">Proyectos</a>
            <button className="w-full mt-4 flex justify-center items-center gap-2 bg-blue-950 hover:bg-blue-900 text-white px-6 py-3 rounded-md font-semibold transition-colors shadow-sm">
              Contacto Rápido
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};
