import { Mail, Clock, Link as LinkIcon } from "lucide-react";

export function TopBar() {
  return (
    <div className="bg-slate-900 text-slate-300 py-1.5 text-xs">
      <div className="container mx-auto px-4 md:px-6 flex flex-col sm:flex-row justify-between items-center gap-2">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5">
            <Mail className="w-3.5 h-3.5 text-slate-400" />
            <a href="mailto:soporte@utachatek.com" className="hover:text-white transition-colors">
              soporte@utachatek.com
            </a>
          </div>
          <div className="hidden sm:flex items-center space-x-1.5 border-l border-slate-700 pl-4">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>Lunes a Viernes - 9:00 a 18:00</span>
          </div>
        </div>
        <div>
          <a
            href="#portal"
            className="flex items-center space-x-1 hover:text-white transition-colors border border-slate-700 rounded px-2 py-0.5"
          >
            <LinkIcon className="w-3 h-3" />
            <span>Portal de Clientes</span>
          </a>
        </div>
      </div>
    </div>
  );
}
