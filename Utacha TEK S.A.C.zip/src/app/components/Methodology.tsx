import { motion } from "motion/react";
import { CheckCircle2, ChevronRight, Calculator, HardHat } from "lucide-react";

export function Methodology() {
  const steps = [
    {
      number: "01",
      title: "Evaluación de Frecuencias y Parámetros",
      description: "Análisis de cobertura, topografía e interferencias en el sitio.",
      icon: <CheckCircle2 className="w-8 h-8 text-[#25D366]" />,
    },
    {
      number: "02",
      title: "Presentación de Presupuestos (Opción 1 y 2)",
      description: "Propuestas de diferentes gamas con base en ROI y escalabilidad.",
      icon: <Calculator className="w-8 h-8 text-[#25D366]" />,
    },
    {
      number: "03",
      title: "Implementación y Soporte Continuo",
      description: "Despliegue táctico, capacitación y mantenimiento preventivo.",
      icon: <HardHat className="w-8 h-8 text-[#25D366]" />,
    },
  ];

  return (
    <section className="py-24 bg-white" id="metodologia">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <span className="text-sm font-bold text-[#25D366] uppercase tracking-wider mb-2 block">
            Cómo trabajamos
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4 tracking-tight">
            Metodología de Proyecto
          </h2>
          <p className="text-lg text-slate-600">
            Un enfoque ingenieril y estructurado para garantizar el éxito de su red de radiocomunicación.
          </p>
        </div>

        <div className="relative">
          {/* Connector line for desktop */}
          <div className="hidden lg:block absolute top-12 left-[10%] right-[10%] h-0.5 bg-slate-100 -z-10"></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-8">
            {steps.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2, duration: 0.6 }}
                className="relative flex flex-col items-center text-center"
              >
                <div className="w-24 h-24 rounded-full bg-slate-50 border-4 border-white shadow-xl shadow-slate-200/50 flex items-center justify-center mb-8 relative z-10">
                  {step.icon}
                  <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm font-bold shadow-lg shadow-slate-900/20">
                    {step.number}
                  </div>
                </div>
                
                <h3 className="text-xl font-bold text-slate-900 mb-4 px-4">
                  {step.title}
                </h3>
                <p className="text-slate-600 leading-relaxed max-w-sm">
                  {step.description}
                </p>

                {idx < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-8 text-slate-300 transform -translate-y-1/2">
                    <ChevronRight className="w-8 h-8" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
