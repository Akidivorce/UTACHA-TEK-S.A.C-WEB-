import React from 'react';
import { Radio, Antenna, Network, Headphones, ArrowRight } from 'lucide-react';

const services = [
  {
    title: 'Infraestructura y Repetidoras',
    description: 'Diseño de redes de amplia cobertura para operaciones críticas. Instalación de sistemas de repetición profesional.',
    icon: <Antenna className="w-8 h-8 text-[#0B1120]" />,
    size: 'large',
    gradient: 'from-blue-50 to-blue-100'
  },
  {
    title: 'Terminales de Radiocomunicación',
    description: 'Portátiles y móviles para uso rudo. Certificación IP67, GPS integrado.',
    icon: <Radio className="w-7 h-7 text-[#0B1120]" />,
    size: 'medium',
    gradient: 'from-slate-50 to-slate-100'
  },
  {
    title: 'Sistemas de Antenas y Enlaces',
    description: 'Soluciones punto a punto y punto-multipunto. Enlaces de microondas.',
    icon: <Network className="w-7 h-7 text-[#0B1120]" />,
    size: 'medium',
    gradient: 'from-green-50 to-emerald-100'
  },
  {
    title: 'Consultoría Técnica',
    description: 'Análisis de parámetros, opciones de presupuesto y pruebas de cobertura.',
    icon: <Headphones className="w-7 h-7 text-[#0B1120]" />,
    size: 'medium',
    gradient: 'from-purple-50 to-violet-100'
  }
];

export const BentoGrid = () => {
  return (
    <section className="py-24 bg-slate-50" id="soluciones">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-bold tracking-widest text-blue-600 uppercase mb-3">
            Soluciones Core
          </h2>
          <p className="text-4xl lg:text-5xl font-black text-[#0B1120] tracking-tight leading-tight">
            Ingeniería de Punta a Punta
          </p>
          <p className="text-lg text-slate-600 mt-4">
            Sistemas integrados de radiocomunicación para tu operación
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className={`lg:col-span-2 bg-gradient-to-br ${services[0].gradient} border-2 border-slate-200 rounded-2xl p-8 lg:p-10 shadow-sm hover:shadow-xl transition-all duration-300 group cursor-pointer`}>
            <div className="flex flex-col h-full">
              <div className="inline-flex items-center justify-center p-4 rounded-xl bg-white/60 backdrop-blur-sm mb-6 w-fit shadow-sm">
                {services[0].icon}
              </div>
              <h3 className="text-2xl lg:text-3xl font-black text-[#0B1120] mb-4 leading-tight">
                {services[0].title}
              </h3>
              <p className="text-base text-slate-700 leading-relaxed mb-6 flex-grow">
                {services[0].description}
              </p>
              <div className="flex items-center gap-2 text-sm font-bold text-blue-600 group-hover:gap-3 transition-all">
                Ver más detalles
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          <div className={`bg-gradient-to-br ${services[1].gradient} border-2 border-slate-200 rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 group cursor-pointer`}>
            <div className="flex flex-col h-full">
              <div className="inline-flex items-center justify-center p-3.5 rounded-xl bg-white/60 backdrop-blur-sm mb-5 w-fit shadow-sm">
                {services[1].icon}
              </div>
              <h3 className="text-xl font-black text-[#0B1120] mb-3 leading-tight">
                {services[1].title}
              </h3>
              <p className="text-sm text-slate-700 leading-relaxed mb-4 flex-grow">
                {services[1].description}
              </p>
              <div className="flex items-center gap-2 text-xs font-bold text-blue-600 group-hover:gap-3 transition-all">
                Ver catálogo
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          <div className={`bg-gradient-to-br ${services[2].gradient} border-2 border-slate-200 rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 group cursor-pointer`}>
            <div className="flex flex-col h-full">
              <div className="inline-flex items-center justify-center p-3.5 rounded-xl bg-white/60 backdrop-blur-sm mb-5 w-fit shadow-sm">
                {services[2].icon}
              </div>
              <h3 className="text-xl font-black text-[#0B1120] mb-3 leading-tight">
                {services[2].title}
              </h3>
              <p className="text-sm text-slate-700 leading-relaxed mb-4 flex-grow">
                {services[2].description}
              </p>
              <div className="flex items-center gap-2 text-xs font-bold text-blue-600 group-hover:gap-3 transition-all">
                Ver soluciones
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          <div className={`lg:col-span-2 bg-gradient-to-br ${services[3].gradient} border-2 border-slate-200 rounded-2xl p-8 lg:p-10 shadow-sm hover:shadow-xl transition-all duration-300 group cursor-pointer`}>
            <div className="flex flex-col h-full">
              <div className="inline-flex items-center justify-center p-4 rounded-xl bg-white/60 backdrop-blur-sm mb-6 w-fit shadow-sm">
                {services[3].icon}
              </div>
              <h3 className="text-2xl lg:text-3xl font-black text-[#0B1120] mb-4 leading-tight">
                {services[3].title}
              </h3>
              <p className="text-base text-slate-700 leading-relaxed mb-6 flex-grow">
                {services[3].description}
              </p>
              <div className="flex items-center gap-2 text-sm font-bold text-blue-600 group-hover:gap-3 transition-all">
                Solicitar asesoría
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
