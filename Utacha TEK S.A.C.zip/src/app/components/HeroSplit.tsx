import React from 'react';
import { MessageCircle, ArrowRight, Shield, Zap } from 'lucide-react';

export const HeroSplit = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 overflow-hidden bg-gradient-to-br from-white via-slate-50 to-blue-50">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMDAwMCIgc3Ryb2tlLW9wYWNpdHk9IjAuMDMiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-60"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100 border border-blue-200 mb-6">
              <span className="flex h-2 w-2 rounded-full bg-[#25D366] animate-pulse"></span>
              <span className="text-xs font-bold text-[#0B1120] uppercase tracking-wider">
                Ingeniería en Telecomunicaciones
              </span>
            </div>

            <h1 className="text-5xl lg:text-6xl xl:text-7xl font-black text-[#0B1120] tracking-tight leading-[1.05] mb-6">
              Ingeniería en Radiocomunicación y Conectividad Ininterrumpida
            </h1>

            <p className="text-lg lg:text-xl text-slate-600 leading-relaxed mb-8">
              Diseño, parametrización y despliegue de redes de comunicación a medida. Equipamiento táctico e infraestructura para operaciones críticas.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <button className="inline-flex justify-center items-center gap-2 bg-[#25D366] hover:bg-[#1da851] text-white px-8 py-4 rounded-lg font-bold transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5 text-base">
                <MessageCircle className="w-5 h-5" />
                Cotizar Proyecto
              </button>
              <button className="inline-flex justify-center items-center gap-2 bg-white hover:bg-slate-50 text-[#0B1120] border-2 border-slate-300 px-8 py-4 rounded-lg font-bold transition-all text-base">
                Explorar Soluciones
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="flex items-start gap-3 bg-white/80 backdrop-blur-sm p-4 rounded-lg border border-slate-200">
                <div className="p-2 bg-blue-100 rounded-md">
                  <Shield className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-bold text-[#0B1120] text-sm mb-0.5">Equipos Certificados</p>
                  <p className="text-xs text-slate-600">Motorola, Kenwood, Icom</p>
                </div>
              </div>
              <div className="flex items-start gap-3 bg-white/80 backdrop-blur-sm p-4 rounded-lg border border-slate-200">
                <div className="p-2 bg-green-100 rounded-md">
                  <Zap className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="font-bold text-[#0B1120] text-sm mb-0.5">Soporte 24/7</p>
                  <p className="text-xs text-slate-600">Asistencia técnica continua</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative hidden lg:block">
            <div className="relative h-[600px] w-full rounded-2xl overflow-hidden shadow-2xl border-4 border-white">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-slate-900/40 z-10 mix-blend-overlay"></div>
              <div className="absolute inset-0 bg-[#0B1120]/10 z-10"></div>
              <div className="w-full h-full bg-gradient-to-br from-[#0B1120] via-blue-900 to-slate-800 flex items-center justify-center">
                <div className="relative w-full h-full p-12">
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/30 rounded-full blur-3xl animate-pulse"></div>
                  <div className="relative z-10 flex flex-col items-center justify-center h-full">
                    <div className="mb-8">
                      <svg className="w-32 h-32 text-white/90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0" />
                      </svg>
                    </div>
                    <div className="space-y-3 w-full">
                      <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-3 rounded-lg border border-white/20">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                        <span className="text-white/90 text-sm font-medium">Sistema de Repetidora Activo</span>
                      </div>
                      <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-3 rounded-lg border border-white/20">
                        <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                        <span className="text-white/90 text-sm font-medium">Cobertura: 50 km de radio</span>
                      </div>
                      <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-3 rounded-lg border border-white/20">
                        <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                        <span className="text-white/90 text-sm font-medium">Frecuencias: VHF/UHF</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
