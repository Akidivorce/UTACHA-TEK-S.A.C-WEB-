
  # Utacha TEK S.A.C

  This is a code bundle for Utacha TEK S.A.C. The original project is available at https://www.figma.com/design/yJA4P0zOL93WPqERLQJOWY/Utacha-TEK-S.A.C.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  